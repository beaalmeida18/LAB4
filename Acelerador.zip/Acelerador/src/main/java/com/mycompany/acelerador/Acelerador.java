/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.acelerador;

/**
 *
 * @author Usuario
 */
public class Acelerador {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
